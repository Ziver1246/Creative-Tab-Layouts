package com.ziver.tab_layouts.internal.layout;

import com.ziver.tab_layouts.Config;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.fml.ModList;

import java.util.*;

public final class CtlFallbackPageBuilder {
    private static final int SECTION_HEADER_SIZE = 9;

    private CtlFallbackPageBuilder() {}

    public static int pageCount(ResourceLocation tabId, CtlTabLayout layout, List<ItemStack> vanillaItems, HolderLookup.Provider registries) {
        Map<String, List<ItemStack>> itemsByMod = fallbackItemsByMod(layout, vanillaItems, registries);

        if (itemsByMod.isEmpty()) return 0;

        return switch (Config.FALLBACK_MODE.get()) {
            case BY_MOD_SECTION -> 1;
            case BY_MOD_PAGE -> itemsByMod.size();
        };
    }

    public static boolean hasFallback(ResourceLocation tabId, CtlTabLayout layout, List<ItemStack> vanillaItems, HolderLookup.Provider registries) {
        return pageCount(tabId, layout, vanillaItems, registries) > 0;
    }

    public static Component title(ResourceLocation tabId, CtlTabLayout layout, List<ItemStack> vanillaItems, HolderLookup.Provider registries, int fallbackIndex) {
        Map<String, List<ItemStack>> itemsByMod = fallbackItemsByMod(layout, vanillaItems, registries);

        if (itemsByMod.isEmpty()) {
            return Component.translatable("screen.tab_layouts.fallback.mods");
        }

        return switch (Config.FALLBACK_MODE.get()) {
            case BY_MOD_SECTION -> Component.translatable("screen.tab_layouts.fallback.mods");
            case BY_MOD_PAGE -> {
                String modId = modIdAt(itemsByMod, fallbackIndex);
                yield modDisplayName(modId);
            }
        };
    }

    public static CtlBuiltPage build(ResourceLocation tabId, CtlTabLayout layout, List<ItemStack> vanillaItems, HolderLookup.Provider registries, int fallbackIndex) {
        Map<String, List<ItemStack>> itemsByMod = fallbackItemsByMod(layout, vanillaItems, registries);

        if (itemsByMod.isEmpty()) return emptyPage();

        return switch (Config.FALLBACK_MODE.get()) {
            case BY_MOD_SECTION -> buildByModSection(tabId, itemsByMod);
            case BY_MOD_PAGE -> buildByModPage(tabId, itemsByMod, fallbackIndex);
        };
    }

    private static CtlBuiltPage buildByModSection(ResourceLocation tabId, Map<String, List<ItemStack>> itemsByMod) {
        List<ItemStack> items = new ArrayList<>();
        List<CtlRenderedSection> renderedSections = new ArrayList<>();

        for (Map.Entry<String, List<ItemStack>> entry : itemsByMod.entrySet()) {
            String modId = entry.getKey();
            List<ItemStack> modItems = entry.getValue();

            if (modItems.isEmpty()) continue;

            padToFullRow(items);

            CtlSection section = new CtlSection(fallbackSectionId(tabId, modId), modDisplayName(modId), CtlSectionType.BASE, 0L, renderedSections.size(), List.of());

            renderedSections.add(new CtlRenderedSection(section, items.size() / 9));

            addHeaderRow(items);
            addCopies(items, modItems);
        }

        padToFullRow(items);
        padToMinimumPageSize(items);

        return new CtlBuiltPage(items, renderedSections, false);
    }

    private static CtlBuiltPage buildByModPage(ResourceLocation tabId, Map<String, List<ItemStack>> itemsByMod, int fallbackIndex) {
        String modId = modIdAt(itemsByMod, fallbackIndex);
        List<ItemStack> modItems = itemsByMod.getOrDefault(modId, List.of());

        List<ItemStack> items = new ArrayList<>();
        List<CtlRenderedSection> renderedSections = new ArrayList<>();

        CtlSection section = new CtlSection(fallbackSectionId(tabId, modId), modDisplayName(modId), CtlSectionType.BASE, 0L, 0L, List.of());

        renderedSections.add(new CtlRenderedSection(section, 0));

        addHeaderRow(items);
        addCopies(items, modItems);
        padToFullRow(items);
        padToMinimumPageSize(items);

        return new CtlBuiltPage(items, renderedSections, false);
    }

    private static Map<String, List<ItemStack>> fallbackItemsByMod(CtlTabLayout layout, List<ItemStack> vanillaItems, HolderLookup.Provider registries) {
        Set<Item> claimedItems = claimedItems(layout, registries);
        Set<Item> addedItems = new HashSet<>();

        Map<String, List<ItemStack>> result = new LinkedHashMap<>();

        for (ItemStack stack : vanillaItems) {
            if (stack.isEmpty()) continue;

            Item item = stack.getItem();

            if (claimedItems.contains(item)) continue;
            if (addedItems.contains(item)) continue;

            ResourceLocation itemId = BuiltInRegistries.ITEM.getKey(item);

            String modId = itemId.getNamespace();

            if ("minecraft".equals(modId)) continue;

            addedItems.add(item);
            result.computeIfAbsent(modId, ignored -> new ArrayList<>()).add(stack.copy());
        }

        return result;
    }

    private static Set<Item> claimedItems(CtlTabLayout layout, HolderLookup.Provider registries) {
        Set<Item> claimed = new HashSet<>();

        for (CtlPage page : layout.orderedPages()) {
            CtlBuiltPage builtPage = page.build(registries);

            for (ItemStack stack : builtPage.items()) {
                if (!stack.isEmpty()) {
                    claimed.add(stack.getItem());
                }
            }
        }

        return claimed;
    }

    private static String modIdAt(Map<String, List<ItemStack>> itemsByMod, int index) {
        if (index < 0 || index >= itemsByMod.size()) {
            return itemsByMod.keySet().stream().findFirst().orElse("unknown");
        }

        int current = 0;

        for (String modId : itemsByMod.keySet()) {
            if (current == index) {
                return modId;
            }

            current++;
        }

        return "unknown";
    }

    private static Component modDisplayName(String modId) {
        return ModList.get()
                .getModContainerById(modId)
                .map(container -> Component.literal(container.getModInfo().getDisplayName()))
                .orElse(Component.literal(modId));
    }

    private static ResourceLocation fallbackSectionId(ResourceLocation tabId, String modId) {
        return ResourceLocation.fromNamespaceAndPath(modId,
                "fallback/" + sanitizePath(tabId.getNamespace()) + "/" + sanitizePath(tabId.getPath())
        );
    }

    private static void addHeaderRow(List<ItemStack> items) {
        for (int i = 0; i < SECTION_HEADER_SIZE; i++) {
            items.add(ItemStack.EMPTY);
        }
    }

    private static void addCopies(List<ItemStack> items, List<ItemStack> stacks) {
        for (ItemStack stack : stacks) {
            items.add(stack.copy());
        }
    }

    private static void padToFullRow(List<ItemStack> items) {
        int remainder = items.size() % 9;

        if (remainder == 0) return;

        int padding = 9 - remainder;

        for (int i = 0; i < padding; i++) {
            items.add(ItemStack.EMPTY);
        }
    }

    private static void padToMinimumPageSize(List<ItemStack> items) {
        while (items.size() < 45) {
            items.add(ItemStack.EMPTY);
        }
    }

    private static CtlBuiltPage emptyPage() {
        List<ItemStack> items = new ArrayList<>();

        for (int i = 0; i < 45; i++) {
            items.add(ItemStack.EMPTY);
        }

        return new CtlBuiltPage(items, List.of(), false);
    }

    private static String sanitizePath(String value) {
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);

            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '/' || c == '.') {
                builder.append(c);
            } else if (c >= 'A' && c <= 'Z') {
                builder.append(Character.toLowerCase(c));
            } else {
                builder.append('_');
            }
        }

        if (builder.isEmpty()) return "unknown";

        return builder.toString();
    }
}